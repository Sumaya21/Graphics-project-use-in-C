#include<cstdio>
#include <windows.h> // for MS Windows
#include <GL/glut.h> // GLUT, include glu.h and gl.h
#include<math.h>>
#define PI 3.14159265358979323846

GLfloat i = 0.0f;
void Idle()
{
glutPostRedisplay();//// marks the current window as needing to be redisplayed
}


GLfloat position = 0.0f;
GLfloat speed = 0.1f;

GLfloat position1 = 0.0f;
GLfloat speed1 = 0.03f;

GLfloat position2 = 0.0f;
GLfloat speed2 = 0.01f;


GLfloat position3= 0.0f;
GLfloat speed3 = 0.1f;


/////////////////////
void update(int value) {

    if(position <-1.0)
        position = 1.0f;

    position -= speed;

	glutPostRedisplay();


	glutTimerFunc(100, update, 0);
}
void update1(int value) {

    if(position1 <-1.0)
        position1 = 1.0f;

    position1 -= speed1;

	glutPostRedisplay();


	glutTimerFunc(100, update1, 0);
}



void update2(int value) {

    if(position2 <-1.0)
        position2 = 1.0f;

    position2 -= speed2;

	glutPostRedisplay();


	glutTimerFunc(100, update2, 0);
}

/////////////////////////
void update3(int value)// For car
{
if(position3>1.0)
position3=-1.0f;



position3 +=speed3;
glutPostRedisplay();
glutTimerFunc(150,update3,0);
}
////////////////////////////////////
 //////////////////////////////////////////
void display1() {
glClearColor(1.0f, 1.0f, 1.0f, 0.0f);
glClear(GL_COLOR_BUFFER_BIT);



glBegin(GL_QUADS);

glColor3ub(128, 128, 128);//road 1
glVertex2f(-1.0f,-1.0f);
glVertex2f(1.0f,-1.0f);
glVertex2f(1.0f,-0.50f);
glVertex2f(-1.0f,-0.50f);


glColor3ub(196,195,208);//road 2
glVertex2f(-1.0f,-0.50f);
glVertex2f(1.0f,-0.50f);
glVertex2f(1.0f,-0.45f);
glVertex2f(-1.0f,-0.45f);

glColor3ub(188, 184, 178);//road 3
glVertex2f(-1.0f,-0.45f);
glVertex2f(1.0f,-0.45f);
glVertex2f(1.0f,-0.30f);
glVertex2f(-1.0f,-0.30f);

glColor3ub(166,231,255);//sky
glVertex2f(-1.0f,-0.30f);
glVertex2f(1.0f,-0.30f);
glVertex2f(1.0f,1.0f);
glVertex2f(-1.0f,1.0f);
glEnd();





////////////////////////////////////////////////////////////
             ////////BARI 1 /////////

glBegin(GL_QUADS);
glColor3f(0.8,0.6,0.4);//bari 1
glVertex2f(-0.95f,-0.30f);
glVertex2f(-0.60f,-0.30f);
glVertex2f(-0.60f,0.50f);
glVertex2f(-0.95f,0.50f);

glColor3ub(222,184,135);//bari middle
glVertex2f(-0.96f,0.08f);
glVertex2f(-0.59f,0.08f);
glVertex2f(-0.59f,0.12f);
glVertex2f(-0.96f,0.12f);

glColor3f(0.8,0.4,0.2);//bari low
glVertex2f(-0.97f,-0.30f);
glVertex2f(-0.58f,-0.30f);
glVertex2f(-0.58f,-0.27f);
glVertex2f(-0.97f,-0.27f);

glColor3f(0.8,0.4,0.2);//bari up1
glVertex2f(-0.95f,0.55f);
glVertex2f(-0.90f,0.55f);
glVertex2f(-0.90f,0.62f);
glVertex2f(-0.95f,0.62f);

glColor3f(0.8,0.4,0.2);//bari up2
glVertex2f(-0.96f,0.62f);
glVertex2f(-0.89f,0.62f);
glVertex2f(-0.89f,0.64f);
glVertex2f(-0.96f,0.64f);

glColor3f(0.8,0.4,0.2);//bari up
glVertex2f(-0.97f,0.50f);
glVertex2f(-0.58f,0.50f);
glVertex2f(-0.58f,0.55f);
glVertex2f(-0.97f,0.55f);

glColor3ub(133,109,77);//bari get
glVertex2f(-0.93f,-0.275f);
glVertex2f(-0.85f,-0.275f);
glVertex2f(-0.85f,-0.11f);
glVertex2f(-0.93f,-0.11f);

glColor3f(0.8,0.9,1);//bari janala 1
glVertex2f(-0.68f,-0.20f);
glVertex2f(-0.75f,-0.20f);
glVertex2f(-0.75f,-0.10f);
glVertex2f(-0.68f,-0.10f);


glColor3f(0.8,0.9,1);//bari janala 2
glVertex2f(-0.62f,0.35f);
glVertex2f(-0.69f,0.35f);
glVertex2f(-0.69f,0.25f);
glVertex2f(-0.62f,0.25f);


glColor3f(0.8,0.9,1);//bari janala 3
glVertex2f(-0.75f,0.35f);
glVertex2f(-0.82f,0.35f);
glVertex2f(-0.82f,0.25f);
glVertex2f(-0.75f,0.25f);

glColor3f(0.8,0.9,1);//bari janala 4
glVertex2f(-0.87f,0.35f);
glVertex2f(-0.94f,0.35f);
glVertex2f(-0.94f,0.25f);
glVertex2f(-0.87f,0.25f);
glEnd();

glBegin(GL_TRIANGLES);

glColor3ub(32,178,170);//bari janala matha 1
glVertex2f(-0.68f,-0.10f);
glVertex2f(-0.75f,-0.10f);
glVertex2f(-0.715f,-0.05f);

glColor3ub(32,178,170);//bari janala 2
glVertex2f(-0.62f,0.35f);
glVertex2f(-0.69f,0.35f);
glVertex2f(-0.655f,0.40f);

glColor3ub(32,178,170);//bari janala 3
glVertex2f(-0.75f,0.35f);
glVertex2f(-0.82f,0.35f);
glVertex2f(-0.785f,0.40f);

glColor3ub(32,178,170);//bari janala 4
glVertex2f(-0.87f,0.35f);
glVertex2f(-0.94f,0.35f);
glVertex2f(-0.905f,0.40f);
glEnd();

glBegin(GL_LINES);
////////////////////////////
    ////////j1/////////
glColor3f(0,0,0);
glVertex2f(-0.68f,-0.15f);
glVertex2f(-0.75f,-0.15f);

glVertex2f(-0.715f,-0.20f);
glVertex2f(-0.715f,-0.10f);
/////////////////////////////
     ////j2///////
glVertex2f(-0.62f,0.30f);
glVertex2f(-0.69f,0.30f);

glVertex2f(-0.655f,0.25f);
glVertex2f(-0.655f,0.35f);
///////////////////////////
  /////////j3////////
  glVertex2f(-0.75f,0.30f);
glVertex2f(-0.82f,0.30f);


 glVertex2f(-0.785f,0.25f);
 glVertex2f(-0.785f,0.35f);
/////////////////////////////////////
   /////////j4/////////

   glVertex2f(-0.87f,0.30f);
glVertex2f(-0.94f,0.30f);

glVertex2f(-0.905f,0.25f);
glVertex2f(-0.905f,0.35f);


glEnd();

/////////////////////////////////////
  //////////////Bari 6////////

glBegin(GL_QUADS);
glColor3ub(169,169,169);//bari 6 pison a
glVertex2f(-0.25f,-0.30f);
glVertex2f(0.05f,-0.30f);
glVertex2f(0.05f,0.15f);
glVertex2f(-0.25f,0.15f);

glColor3ub(105,105,105);//bari 6 pison low
glVertex2f(-0.25f,-0.30f);
glVertex2f(0.05f,-0.30f);
glVertex2f(0.05f,-0.27f);
glVertex2f(-0.25f,-0.27f);

glColor3ub(105,105,105);//bari 6 pison up1
glVertex2f(-0.27f,0.15f);
glVertex2f(0.05f,0.15f);
glVertex2f(0.05f,0.18f);
glVertex2f(-0.27f,0.18f);

glColor3ub(117,117,117);//bari 6 pison up2
glVertex2f(-0.26f,0.18f);
glVertex2f(0.05f,0.18f);
glVertex2f(0.05f,0.21f);
glVertex2f(-0.26f,0.21f);

glColor3ub(117,117,117);//bari 6 pison up3
glVertex2f(-0.24f,0.21f);
glVertex2f(-0.20f,0.21f);
glVertex2f(-0.20f,0.26f);
glVertex2f(-0.24f,0.26f);

glColor3ub(117,117,117);//bari 6 pison up3
glVertex2f(-0.25f,0.26f);
glVertex2f(-0.19f,0.26f);
glVertex2f(-0.19f,0.28f);
glVertex2f(-0.25f,0.28f);

glColor3ub(68,76,56);//bari 6 pison get
glVertex2f(-0.19f,-0.27f);
glVertex2f(-0.11f,-0.27f);
glVertex2f(-0.11f,-0.05f);
glVertex2f(-0.19f,-0.05f);
glEnd();

glBegin(GL_TRIANGLES);

glColor3ub(70,89,69);//bari janala matha 1
glVertex2f(-0.20f,-0.05f);
glVertex2f(-0.10f,-0.05f);
glVertex2f(-0.15f,0.05f);
glEnd();

////////////////////////////////////////////////////////////////
            ////////////BARI 2///////////////


glBegin(GL_QUADS);

glColor3ub(254,90,29);//bari 2
glVertex2f(-0.50f,-0.30f);
glVertex2f(-0.20f,-0.30f);
glVertex2f(-0.20f,0.05f);
glVertex2f(-0.50f,0.05f);

glColor3ub(222,184,135);//bari 2 low
glVertex2f(-0.52f,-0.30f);
glVertex2f(-0.18f,-0.30f);
glVertex2f(-0.18f,-0.27f);
glVertex2f(-0.52f,-0.27f);

glColor3ub(222,184,135);//bari 2 get
glVertex2f(-0.48f,-0.30f);
glVertex2f(-0.42f,-0.30f);
glVertex2f(-0.42f,-0.10f);
glVertex2f(-0.48f,-0.10f);

glColor3ub(136,216,192);//bari 2 janala
glVertex2f(-0.36f,-0.23f);
glVertex2f(-0.26f,-0.23f);
glVertex2f(-0.26f,-0.15f);
glVertex2f(-0.36f,-0.15f);

glEnd();

glBegin(GL_TRIANGLES);

glColor3ub(254,90,29);//bari 2
glVertex2f(-0.50f,0.05f);
glVertex2f(-0.20f,0.05f);
glVertex2f(-0.35f,0.15f);

glColor3ub(32,178,170);//bari 2 janala
glVertex2f(-0.36f,-0.15f);
glVertex2f(-0.26f,-0.15f);
glVertex2f(-0.31f,-0.05f);

glEnd();

glBegin(GL_QUADS);
glColor3ub(152,118,84);//bari 2 chal ar upor
glVertex2f(-0.50f,0.10f);
glVertex2f(-0.45f,0.10f);
glVertex2f(-0.45f,0.20f);
glVertex2f(-0.50f,0.20f);

glColor3ub(152,118,84);//bari 2 chal ar upor
glVertex2f(-0.51f,0.20f);
glVertex2f(-0.44f,0.20f);
glVertex2f(-0.44f,0.22f);
glVertex2f(-0.51f,0.22f);

glColor3ub(152,118,84);//bari 2 chal
glVertex2f(-0.17f,0.09f);
glVertex2f(-0.35f,0.25f);
glVertex2f(-0.35f,0.15f);
glVertex2f(-0.17f,0.00f);

glColor3ub(152,118,84);//bari 2 chal
glVertex2f(-0.53f,0.09f);
glVertex2f(-0.35f,0.25f);
glVertex2f(-0.35f,0.15f);
glVertex2f(-0.53f,0.00f);
glEnd();

glBegin(GL_LINES);
glColor3f(0,0,0);
glVertex2f(-0.26f,-0.19f);
glVertex2f(-0.36f,-0.19f);

glVertex2f(-0.31f,-0.23f);
glVertex2f(-0.31f,-0.15f);


glEnd();

////////////////////////////////////////////////////////////
         ////////////////tree/////////////



  glBegin(GL_QUADS);
glColor3ub(72,6,7);//tree
glVertex2f(0.18f,-0.30f);
glVertex2f(0.21f,-0.30f);
glVertex2f(0.21f,-0.15f);
glVertex2f(0.18f,-0.15f);
glEnd();

glBegin(GL_TRIANGLES);
glColor3ub(34,139,34);//tree
glVertex2f(0.15f,-0.20f);
glVertex2f(0.24f,-0.20f);
glVertex2f(0.195f,-0.00f);

glVertex2f(0.15f,-0.15f);
glVertex2f(0.24f,-0.15f);
glVertex2f(0.195f,0.05f);

glVertex2f(0.15f,-0.10f);
glVertex2f(0.24f,-0.10f);
glVertex2f(0.195f,0.10f);

glEnd();



////////////////////////////////////////////////
    ////////////BARI 3///////////////


glBegin(GL_QUADS);
glColor3ub(115,134,120);//bari 3
glVertex2f(-0.10f,-0.30f);
glVertex2f(0.15f,-0.30f);
glVertex2f(0.15f,0.40f);
glVertex2f(-0.10f,0.40f);


glColor3ub(38,67,72);//bari 3
glVertex2f(-0.12f,-0.30f);
glVertex2f(0.17f,-0.30f);
glVertex2f(0.17f,-0.27f);
glVertex2f(-0.12f,-0.27f);

glEnd();

glBegin(GL_TRIANGLES);

glColor3ub(120,134,107);//bari 3 matha
glVertex2f(-0.10f,0.40f);
glVertex2f(0.15f,0.40f);
glVertex2f(0.025f,0.55f);
glEnd();

GLfloat x_2 =0.025; GLfloat y_2 = 0.455; GLfloat radius_2 =0.03;//ghori
int triangleAmount = 20; //# of triangles used to draw circle

GLfloat radius = 0.8f; //radius
GLfloat twicePi = 2.0f * PI;

glBegin(GL_TRIANGLE_FAN);//chaka1
glColor3ub(255,255,255);
glVertex2f(x_2 , y_2); // center of circle
for(int i = 0; i <= triangleAmount;i++) {
glVertex2f(
x_2 + (radius_2 * cos(i * twicePi / triangleAmount)),
y_2 + (radius_2 * sin(i * twicePi / triangleAmount))
);
}
glEnd();


glLoadIdentity();
glPushMatrix(); //glPushMatrix copies the top matrix and pushes it onto the stack, while glPopMatrix pops the top matrix off the stack
glTranslatef(.025,0.45,0);
glRotatef(i,0,0,.2);//i=how many degree you want to rotate around an axis



glBegin(GL_LINES);
glColor3ub(0,0,0);
glVertex2f(0.0,0.0);
glVertex2f(0.0,0.015);

glEnd();

glPopMatrix();
i-=0.05f;
glLoadIdentity();

glBegin(GL_LINES);
glLineWidth(05);
glColor3ub(248,248,255);
glVertex2f(-0.05f,-0.27f);
glVertex2f(-0.05f,0.40f);

glVertex2f(-0.0f,-0.27f);
glVertex2f(-0.0f,0.40f);

glVertex2f(0.05f,-0.27f);
glVertex2f(0.05f,0.40f);

glVertex2f(0.10f,-0.27f);
glVertex2f(0.10f,0.40f);

glEnd();
//////////////////////////////////////////////////
    //////////////////bari 7/////////////



    glBegin(GL_QUADS);
glColor3ub(172,30,68);//bari 7
glVertex2f(0.30f,-0.30f);
glVertex2f(0.63f,-0.30f);
glVertex2f(0.63f,0.30f);
glVertex2f(0.30f,0.30f);

glColor3ub(209,0,86);//bari 7up
glVertex2f(0.28f,0.30f);
glVertex2f(0.65f,0.30f);
glVertex2f(0.65f,0.35f);
glVertex2f(0.28f,0.35f);


glColor3ub(176,48,96);//bari 7 up
glVertex2f(0.60f,0.35f);
glVertex2f(0.55f,0.35f);
glVertex2f(0.55f,0.42f);
glVertex2f(0.60f,0.42f);

glColor3ub(176,48,96);//bari 7 up
glVertex2f(0.61f,0.42f);
glVertex2f(0.54f,0.42f);
glVertex2f(0.54f,0.44f);
glVertex2f(0.61f,0.44f);


glColor3ub(229,228,226);//bari 7 up j1
glVertex2f(0.33f,0.20f);
glVertex2f(0.39f,0.20f);
glVertex2f(0.39f,0.13f);
glVertex2f(0.33f,0.13f);

glColor3ub(229,228,226);//bari 7 upj2
glVertex2f(0.42f,0.20f);
glVertex2f(0.48f,0.20f);
glVertex2f(0.48f,0.13f);
glVertex2f(0.42f,0.13f);

glColor3ub(229,228,226);//bari 7 low j
glVertex2f(0.42f,-0.17f);
glVertex2f(0.48f,-0.17f);
glVertex2f(0.48f,-0.10f);
glVertex2f(0.42f,-0.10f);

glColor3ub(229,228,226);//bari 7 up 3
glVertex2f(0.52f,0.20f);
glVertex2f(0.58f,0.20f);
glVertex2f(0.58f,0.13f);
glVertex2f(0.52f,0.13f);

glEnd();

//////////////////////////////////////////////
      ///////////bari 4////////////


    glBegin(GL_QUADS);
glColor3ub(191, 121, 36);//bari 4
glVertex2f(0.25f,-0.30f);
glVertex2f(0.55f,-0.30f);
glVertex2f(0.55f,0.10f);
glVertex2f(0.25f,0.10f);

glColor3ub(89,39,32);//bari down
glVertex2f(0.24f,-0.27f);
glVertex2f(0.56f,-0.27f);
glVertex2f(0.56f,-0.30f);
glVertex2f(0.24f,-0.30f);



glColor3ub(90, 0, 0);//bari up
glVertex2f(0.25f,0.10f);
glVertex2f(0.55f,0.10f);
glVertex2f(0.60f,-0.05f);
glVertex2f(0.20f,-0.05f);

glColor3ub(222,184,135);//bari get
glVertex2f(0.53f,-0.27f);
glVertex2f(0.46f,-0.27f);
glVertex2f(0.46f,-0.10f);
glVertex2f(0.53f,-0.10f);

glColor3ub(250,235,215);//bari 4 janala
glVertex2f(0.32f,-0.23f);
glVertex2f(0.40f,-0.23f);
glVertex2f(0.40f,-0.15f);
glVertex2f(0.32f,-0.15f);

glEnd();

//////////////////////////////////////////////
  /////////////////Bari 5//////////
glBegin(GL_QUADS);
glColor3ub(201, 135, 19);//bari 5
glVertex2f(0.97f,-0.30f);
glVertex2f(0.65f,-0.30f);
glVertex2f(0.65f,0.05f);
glVertex2f(0.97f,0.05f);

glColor3ub(103, 64, 59);//bari 5
glVertex2f(0.99f,0.05f);
glVertex2f(0.63f,0.05f);
glVertex2f(0.63f,0.07f);
glVertex2f(0.99f,0.07f);

glColor3ub(201, 135, 19);//bari 5
glVertex2f(0.93f,0.07f);
glVertex2f(0.70f,0.07f);
glVertex2f(0.70f,0.20f);
glVertex2f(0.93f,0.20f);

glColor3ub(103, 64, 59);//bari 5 low
glVertex2f(0.99f,-0.30f);
glVertex2f(0.63f,-0.30f);
glVertex2f(0.63f,-0.27f);
glVertex2f(0.99f,-0.27f);

glColor3ub(103, 64, 59);//bari 5 get
glVertex2f(0.77f,-0.27f);
glVertex2f(0.87f,-0.27f);
glVertex2f(0.87f,-0.10f);
glVertex2f(0.77f,-0.10f);

glColor3ub(112,128,144);//bari 5 get
glVertex2f(0.79f,-0.27f);
glVertex2f(0.85f,-0.27f);
glVertex2f(0.85f,-0.14f);
glVertex2f(0.79f,-0.14f);

glColor3ub(0,0,0);//bari 5 janala 1
glVertex2f(0.69f,-0.25f);
glVertex2f(0.74f,-0.25f);
glVertex2f(0.74f,-0.19f);
glVertex2f(0.69f,-0.19f);

glVertex2f(0.69f,-0.17f);//janala 2
glVertex2f(0.74f,-0.17f);
glVertex2f(0.74f,-0.11f);
glVertex2f(0.69f,-0.11f);

glVertex2f(0.69f,-0.09f);//janala 3
glVertex2f(0.74f,-0.09f);
glVertex2f(0.74f,-0.03f);
glVertex2f(0.69f,-0.03f);


glColor3ub(0,0,0);//bari 5 janala 4
glVertex2f(0.95f,-0.25f);
glVertex2f(0.90f,-0.25f);
glVertex2f(0.90f,-0.19f);
glVertex2f(0.95f,-0.19f);

glVertex2f(0.95f,-0.17f);//janala 5
glVertex2f(0.90f,-0.17f);
glVertex2f(0.90f,-0.11f);
glVertex2f(0.95f,-0.11f);

glVertex2f(0.95f,-0.09f);//janala 6
glVertex2f(0.90f,-0.09f);
glVertex2f(0.90f,-0.03f);
glVertex2f(0.95f,-0.03f);
glEnd();

glBegin(GL_TRIANGLES);

glColor3ub(103, 64, 59);//bari 5 matha
glVertex2f(0.68f,0.20f);
glVertex2f(0.95f,0.20f);
glVertex2f(0.815f,0.30f);

glColor3ub(72,6,7);//bari 5 matha
glVertex2f(0.75f,-0.10f);
glVertex2f(0.89f,-0.10f);
glVertex2f(0.82f,-0.05f);

glEnd();


////////////////////////////////////////
      ///////stap//////////

glBegin(GL_QUADS);
glColor3ub(255,255,255);//stap 1
glVertex2f(-0.15f,-0.75f);
glVertex2f(-0.30f,-0.75f);
glVertex2f(-0.30f,-0.80f);
glVertex2f(-0.15f,-0.80f);

glColor3ub(255,255,255);//stap 2
glVertex2f(0.15f,-0.75f);
glVertex2f(0.30f,-0.75f);
glVertex2f(0.30f,-0.80f);
glVertex2f(0.15f,-0.80f);

glColor3ub(255,255,255);//stap 3
glVertex2f(-0.50f,-0.75f);
glVertex2f(-0.70f,-0.75f);
glVertex2f(-0.70f,-0.80f);
glVertex2f(-0.50f,-0.80f);


glColor3ub(255,255,255);//stap 4
glVertex2f(-1.0f,-0.75f);
glVertex2f(-0.90f,-0.75f);
glVertex2f(-0.90f,-0.80f);
glVertex2f(-1.0f,-0.80f);

glColor3ub(255,255,255);//stap 5
glVertex2f(0.50f,-0.75f);
glVertex2f(0.70f,-0.75f);
glVertex2f(0.70f,-0.80f);
glVertex2f(0.50f,-0.80f);

glColor3ub(255,255,255);//stap 6
glVertex2f(1.0f,-0.75f);
glVertex2f(0.90f,-0.75f);
glVertex2f(0.90f,-0.80f);
glVertex2f(1.0f,-0.80f);


glEnd();



////////////////////////////////////////////////////////
       ///////////////CAR///////////////



glPushMatrix();
glTranslatef(position,0.0f, 0.0f);
   glBegin(GL_QUADS);
      glColor3f(1.0f, 0.0f, 0.0f);
      glVertex2f(-0.10f, -0.80f);
      glVertex2f( 0.10f, -0.80f);
      glVertex2f( 0.10f,  -0.90f);
      glVertex2f(-0.10f,  -0.90f);



      glColor3f(1.0f, 0.0f, 0.0f);
      glVertex2f(-0.10f, -0.80f);
      glVertex2f( 0.00f, -0.80f);
      glVertex2f( 0.00f,  -0.75f);
      glVertex2f(-0.10f,  -0.75f);



   glEnd();
GLfloat x_3 =-0.05; GLfloat y_3= -0.90; GLfloat radius_3 =-0.02;

glBegin(GL_TRIANGLE_FAN);//chaka1
glColor3f(0,0,0);
glVertex2f(x_3 , y_3); // center of circle
for(int i = 0; i <= triangleAmount;i++) {
glVertex2f(
x_3 + (radius_3 * cos(i * twicePi / triangleAmount)),
y_3 + (radius_3 * sin(i * twicePi / triangleAmount))
);
}
glEnd();

GLfloat x_4 =0.05; GLfloat y_4= -0.90; GLfloat radius_4 =-0.02;

glBegin(GL_TRIANGLE_FAN);//chaka1
glColor3f(0,0,0);
glVertex2f(x_4 , y_4); // center of circle
for(int i = 0; i <= triangleAmount;i++) {
glVertex2f(
x_4 + (radius_4 * cos(i * twicePi / triangleAmount)),
y_4 + (radius_4 * sin(i * twicePi / triangleAmount))
);
}
glEnd();

glPopMatrix();
//////////////////////////////////////////
//////////////////sun///////////

GLfloat x_5=0.90; GLfloat y_5=0.90; GLfloat radius_5=0.15;

glBegin(GL_TRIANGLE_FAN);//chaka1
glColor3ub(244,196,48);
glVertex2f(x_5 , y_5); // center of circle
for(int i = 0; i <= triangleAmount;i++) {
glVertex2f(
x_5 + (radius_5 * cos(i * twicePi / triangleAmount)),
y_5 + (radius_5 * sin(i * twicePi / triangleAmount))
);
}
glEnd();
////////////////////////////////////////////////////////
    /////////////////////clouds//////////////
glPushMatrix();
glTranslatef(position1,.0f, 0.0f);




GLfloat x_6 =0.0; GLfloat y_6 =0.80; GLfloat radius_6 =0.10;

glBegin(GL_TRIANGLE_FAN);//chaka1
glColor3ub(255,255,255);
glVertex2f(x_6 , y_6); // center of circle
for(int i = 0; i <= triangleAmount;i++) {
glVertex2f(
x_6 + (radius_6 * cos(i * twicePi / triangleAmount)),
y_6 + (radius_6 * sin(i * twicePi / triangleAmount))
);
}
glEnd();

GLfloat x_7 =0.05; GLfloat y_7= 0.85; GLfloat radius_7 =0.10;

glBegin(GL_TRIANGLE_FAN);//chaka1
glColor3ub(255,255,255);
glVertex2f(x_7 , y_7); // center of circle
for(int i = 0; i <= triangleAmount;i++) {
glVertex2f(
x_7 + (radius_7 * cos(i * twicePi / triangleAmount)),
y_7 + (radius_7 * sin(i * twicePi / triangleAmount))
);
}
glEnd();


GLfloat x_8 =0.05; GLfloat y_8= 0.78; GLfloat radius_8 =0.10;

glBegin(GL_TRIANGLE_FAN);//chaka1
glColor3ub(255,255,255);
glVertex2f(x_8 , y_8); // center of circle
for(int i = 0; i <= triangleAmount;i++) {
glVertex2f(
x_8 + (radius_8 * cos(i * twicePi / triangleAmount)),
y_8 + (radius_8 * sin(i * twicePi / triangleAmount))
);
}
glEnd();

GLfloat x_9 =0.15; GLfloat y_9= 0.78; GLfloat radius_9=0.10;

glBegin(GL_TRIANGLE_FAN);//chaka1
glColor3f(255,255,255);
glVertex2f(x_9 , y_9); // center of circle
for(int i = 0; i <= triangleAmount;i++) {
glVertex2f(
x_9 + (radius_9 * cos(i * twicePi / triangleAmount)),
y_9 + (radius_9 * sin(i * twicePi / triangleAmount))
);
}
glEnd();

glPopMatrix();


//////////////////////////////////////////
    ///////////////clouds 2/////////////

glPushMatrix();
glTranslatef(position2,.0f, 0.0f);




GLfloat x_10 =0.0; GLfloat y_10 =0.80; GLfloat radius_10 =0.10;

glBegin(GL_TRIANGLE_FAN);//chaka1
glColor3ub(255,255,255);
glVertex2f(x_10 , y_10); // center of circle
for(int i = 0; i <= triangleAmount;i++) {
glVertex2f(
x_10 + (radius_10 * cos(i * twicePi / triangleAmount)),
y_10 + (radius_10 * sin(i * twicePi / triangleAmount))
);
}
glEnd();

GLfloat x_11 =0.05; GLfloat y_11= 0.85; GLfloat radius_11 =0.10;

glBegin(GL_TRIANGLE_FAN);//chaka1
glColor3ub(255,255,255);
glVertex2f(x_11 , y_11); // center of circle
for(int i = 0; i <= triangleAmount;i++) {
glVertex2f(
x_11 + (radius_11 * cos(i * twicePi / triangleAmount)),
y_11 + (radius_11 * sin(i * twicePi / triangleAmount))
);
}
glEnd();


GLfloat x_12 =0.05; GLfloat y_12= 0.78; GLfloat radius_12 =0.10;

glBegin(GL_TRIANGLE_FAN);//chaka1
glColor3ub(255,255,255);
glVertex2f(x_12 , y_12); // center of circle
for(int i = 0; i <= triangleAmount;i++) {
glVertex2f(
x_12 + (radius_12 * cos(i * twicePi / triangleAmount)),
y_12 + (radius_12 * sin(i * twicePi / triangleAmount))
);
}
glEnd();

GLfloat x_13 =0.15; GLfloat y_13= 0.78; GLfloat radius_13=0.10;

glBegin(GL_TRIANGLE_FAN);//chaka1
glColor3f(255,255,255);
glVertex2f(x_13 , y_13); // center of circle
for(int i = 0; i <= triangleAmount;i++) {
glVertex2f(
x_13 + (radius_13 * cos(i * twicePi / triangleAmount)),
y_13 + (radius_13 * sin(i * twicePi / triangleAmount))
);
}
glEnd();

glPopMatrix();

////////////////////////////////////////
   //////////tree//////////
glBegin(GL_QUADS);
glColor3ub(146,39,36);//bari 2 chal ar upor
glVertex2f(-0.57f,-0.10f);
glVertex2f(-0.54f,-0.10f);
glVertex2f(-0.54f,-0.30f);
glVertex2f(-0.57f,-0.30f);
glEnd();

GLfloat x_14 =-0.58; GLfloat y_14=-0.10; GLfloat radius_14=-0.03;

glBegin(GL_TRIANGLE_FAN);//chaka1
glColor3ub(50,205,50);
glVertex2f(x_14 , y_14); // center of circle
for(int i = 0; i <= triangleAmount;i++) {
glVertex2f(
x_14 + (radius_14 * cos(i * twicePi / triangleAmount)),
y_14 + (radius_14 * sin(i * twicePi / triangleAmount))
);
}
glEnd();

GLfloat x_15 =-0.58; GLfloat y_15=-0.15; GLfloat radius_15=-0.03;

glBegin(GL_TRIANGLE_FAN);//chaka1
glColor3ub(50,205,50);
glVertex2f(x_15 , y_15); // center of circle
for(int i = 0; i <= triangleAmount;i++) {
glVertex2f(
x_15 + (radius_15 * cos(i * twicePi / triangleAmount)),
y_15 + (radius_15 * sin(i * twicePi / triangleAmount))
);
}
glEnd();

GLfloat x_16 =-0.55; GLfloat y_16=-0.07; GLfloat radius_16=-0.03;

glBegin(GL_TRIANGLE_FAN);//chaka1
glColor3ub(50,205,50);
glVertex2f(x_16 , y_16); // center of circle
for(int i = 0; i <= triangleAmount;i++) {
glVertex2f(
x_16 + (radius_16 * cos(i * twicePi / triangleAmount)),
y_16 + (radius_16 * sin(i * twicePi / triangleAmount))
);
}
glEnd();

GLfloat x_17 =-0.52; GLfloat y_17=-0.09; GLfloat radius_17=-0.03;

glBegin(GL_TRIANGLE_FAN);//chaka1
glColor3ub(50,205,50);
glVertex2f(x_17 , y_17); // center of circle
for(int i = 0; i <= triangleAmount;i++) {
glVertex2f(
x_17 + (radius_17 * cos(i * twicePi / triangleAmount)),
y_17 + (radius_17 * sin(i * twicePi / triangleAmount))
);
}
glEnd();

GLfloat x_18 =-0.52; GLfloat y_18=-0.14; GLfloat radius_18=-0.03;

glBegin(GL_TRIANGLE_FAN);//chaka1
glColor3ub(50,205,50);
glVertex2f(x_18 , y_18); // center of circle
for(int i = 0; i <= triangleAmount;i++) {
glVertex2f(
x_18 + (radius_18 * cos(i * twicePi / triangleAmount)),
y_18 + (radius_18 * sin(i * twicePi / triangleAmount))
);
}
glEnd();

GLfloat x_19 =-0.55; GLfloat y_19=-0.17; GLfloat radius_19=-0.03;

glBegin(GL_TRIANGLE_FAN);//chaka1
glColor3ub(50,205,50);
glVertex2f(x_19 , y_19); // center of circle
for(int i = 0; i <= triangleAmount;i++) {
glVertex2f(
x_19 + (radius_19 * cos(i * twicePi / triangleAmount)),
y_19 + (radius_19 * sin(i * twicePi / triangleAmount))
);
}
glEnd();

GLfloat x_20 =-0.55; GLfloat y_20=-0.13; GLfloat radius_20=-0.03;

glBegin(GL_TRIANGLE_FAN);//chaka1
glColor3ub(50,205,50);
glVertex2f(x_20 , y_20); // center of circle
for(int i = 0; i <= triangleAmount;i++) {
glVertex2f(
x_20 + (radius_20 * cos(i * twicePi / triangleAmount)),
y_20 + (radius_20 * sin(i * twicePi / triangleAmount))
);
}
glEnd();





/////////////////////////////////////////////////////////
       /////////////////car2//////////////


glPushMatrix();
 glTranslatef(position3,0.0f, 0.0f);
   glBegin(GL_QUADS);
      glColor3ub(138,51,36);
      glVertex2f(-0.13f, -0.50f);
      glVertex2f( 0.12f, -0.50f);
      glVertex2f( 0.12f,  -0.60f);
      glVertex2f(-0.13f,  -0.60f);



      glColor3ub(145,129,81);
      glVertex2f(-0.10f, -0.50f);
      glVertex2f( 0.09f, -0.50f);
      glVertex2f( 0.06f,  -0.45f);
      glVertex2f(-0.05f,  -0.45f);



   glEnd();
GLfloat x_21 =-0.05; GLfloat y_21= -0.60; GLfloat radius_21 =-0.02;

glBegin(GL_TRIANGLE_FAN);//chaka1
glColor3f(0,0,0);
glVertex2f(x_21 , y_21); // center of circle
for(int i = 0; i <= triangleAmount;i++) {
glVertex2f(
x_21 + (radius_21 * cos(i * twicePi / triangleAmount)),
y_21 + (radius_21 * sin(i * twicePi / triangleAmount))
);
}
glEnd();

GLfloat x_22 =0.05; GLfloat y_22= -0.60; GLfloat radius_22 =-0.02;

glBegin(GL_TRIANGLE_FAN);//chaka1
glColor3f(0,0,0);
glVertex2f(x_22 , y_22); // center of circle
for(int i = 0; i <= triangleAmount;i++) {
glVertex2f(
x_22 + (radius_22 * cos(i * twicePi / triangleAmount)),
y_22 + (radius_22 * sin(i * twicePi / triangleAmount))
);
}
glEnd();

glPopMatrix();



////////////////////////////////////////
   /////////////road side light///////////

   glBegin(GL_QUADS);
glColor3ub(0,0,0);//light 1
glVertex2f(-0.80f,-0.48f);
glVertex2f(-0.815f,-0.48f);
glVertex2f(-0.815f,-0.33f);
glVertex2f(-0.80f,-0.33f);


glColor3ub(0,0,0);//light 1
glVertex2f(-0.78f,-0.33f);
glVertex2f(-0.835f,-0.33f);
glVertex2f(-0.845f,-0.28f);
glVertex2f(-0.77f,-0.28f);

glColor3ub(0,0,0);//light 1
glVertex2f(-0.80f,-0.28f);
glVertex2f(-0.815f,-0.28f);
glVertex2f(-0.815f,-0.27f);
glVertex2f(-0.80f,-0.27f);

glColor3ub(0,0,0);//light 1
glVertex2f(-0.78f,-0.27f);
glVertex2f(-0.835f,-0.27f);
glVertex2f(-0.845f,-0.22f);
glVertex2f(-0.77f,-0.22f);

glColor3ub(0,0,0);//light 1
glVertex2f(-0.80f,-0.22f);
glVertex2f(-0.815f,-0.22f);
glVertex2f(-0.815f,-0.21f);
glVertex2f(-0.80f,-0.21f);

glColor3ub(0,0,0);//light 1
glVertex2f(-0.78f,-0.21f);
glVertex2f(-0.835f,-0.21f);
glVertex2f(-0.845f,-0.15f);
glVertex2f(-0.77f,-0.15f);

glEnd();
//////////////////////////////////

/////////////road side light///////////

   glBegin(GL_QUADS);
glColor3ub(0,0,0);//light 2
glVertex2f(0.80f,-0.48f);
glVertex2f(0.815f,-0.48f);
glVertex2f(0.815f,-0.33f);
glVertex2f(0.80f,-0.33f);


glColor3ub(0,0,0);//light 2
glVertex2f(0.78f,-0.33f);
glVertex2f(0.835f,-0.33f);
glVertex2f(0.845f,-0.28f);
glVertex2f(0.77f,-0.28f);

glColor3ub(0,0,0);//light 2
glVertex2f(0.80f,-0.28f);
glVertex2f(0.815f,-0.28f);
glVertex2f(0.815f,-0.27f);
glVertex2f(0.80f,-0.27f);

glColor3ub(0,0,0);//light 2
glVertex2f(0.78f,-0.27f);
glVertex2f(0.835f,-0.27f);
glVertex2f(0.845f,-0.22f);
glVertex2f(0.77f,-0.22f);

glColor3ub(0,0,0);//light 2
glVertex2f(0.80f,-0.22f);
glVertex2f(0.815f,-0.22f);
glVertex2f(0.815f,-0.21f);
glVertex2f(0.80f,-0.21f);

glColor3ub(0,0,0);//light 2
glVertex2f(0.78f,-0.21f);
glVertex2f(0.835f,-0.21f);
glVertex2f(0.845f,-0.15f);
glVertex2f(0.77f,-0.15f);

 glEnd();



 GLfloat x_23 =-0.81; GLfloat y_23=-0.305; GLfloat radius_23 =-0.015;

glBegin(GL_TRIANGLE_FAN);//chaka1
glColor3ub(34,139,34);
glVertex2f(x_23 , y_23); // center of circle
for(int i = 0; i <= triangleAmount;i++) {
glVertex2f(
x_23 + (radius_23 * cos(i * twicePi / triangleAmount)),
y_23 + (radius_23 * sin(i * twicePi / triangleAmount))
);
}
glEnd();


GLfloat x_24 =-0.81; GLfloat y_24=-0.245; GLfloat radius_24 =-0.015;

glBegin(GL_TRIANGLE_FAN);//chaka1
glColor3ub(253,238,0);
glVertex2f(x_24 , y_24); // center of circle
for(int i = 0; i <= triangleAmount;i++) {
glVertex2f(
x_24 + (radius_24 * cos(i * twicePi / triangleAmount)),
y_24 + (radius_24 * sin(i * twicePi / triangleAmount))
);
}
glEnd();





GLfloat x_25 =-0.81; GLfloat y_25=-0.175; GLfloat radius_25 =-0.015;

glBegin(GL_TRIANGLE_FAN);//chaka1
glColor3ub(255,0,0);
glVertex2f(x_25 , y_25); // center of circle
for(int i = 0; i <= triangleAmount;i++) {
glVertex2f(
x_25 + (radius_25 * cos(i * twicePi / triangleAmount)),
y_25 + (radius_25 * sin(i * twicePi / triangleAmount))
);
}
glEnd();



GLfloat x_26 =0.81; GLfloat y_26=-0.305; GLfloat radius_26 =-0.015;

glBegin(GL_TRIANGLE_FAN);//chaka1
glColor3ub(34,139,34);
glVertex2f(x_26 , y_26); // center of circle
for(int i = 0; i <= triangleAmount;i++) {
glVertex2f(
x_26 + (radius_26 * cos(i * twicePi / triangleAmount)),
y_26 + (radius_26 * sin(i * twicePi / triangleAmount))
);
}
glEnd();


GLfloat x_27 =0.81; GLfloat y_27=-0.245; GLfloat radius_27 =-0.015;

glBegin(GL_TRIANGLE_FAN);//chaka1
glColor3ub(253,238,0);
glVertex2f(x_27 , y_27); // center of circle
for(int i = 0; i <= triangleAmount;i++) {
glVertex2f(
x_27 + (radius_27 * cos(i * twicePi / triangleAmount)),
y_27 + (radius_27 * sin(i * twicePi / triangleAmount))
);
}
glEnd();





GLfloat x_28 =0.81; GLfloat y_28=-0.175; GLfloat radius_28 =-0.015;

glBegin(GL_TRIANGLE_FAN);//chaka1
glColor3ub(255,0,0);
glVertex2f(x_28 , y_28); // center of circle
for(int i = 0; i <= triangleAmount;i++) {
glVertex2f(
x_28 + (radius_28 * cos(i * twicePi / triangleAmount)),
y_28 + (radius_28 * sin(i * twicePi / triangleAmount))
);
}
glEnd();






glFlush();
}



int main(int argc, char** argv) {
glutInit(&argc, argv);
glutCreateWindow("Test");
glutInitWindowSize(520, 520);
glutDisplayFunc(display1);
glutIdleFunc(Idle);
glutTimerFunc(100, update, 0);
glutTimerFunc(100, update1, 0);
glutTimerFunc(100, update2, 0);
glutTimerFunc(100, update3, 0);
glutMainLoop();
return 0;
}

